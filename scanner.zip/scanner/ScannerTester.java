package scanner;


public class ScannerTester
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner("x = pleasework.");
        if(scanner.hasNext())
        {
            System.out.println("hasNext() returns true");
        }
        if(Scanner.isDigit('0') && Scanner.isDigit('8') && !Scanner.isDigit('a'))
        {
            System.out.println("isDigit pass");
        }
        if(Scanner.isLetter('B') && Scanner.isLetter('z') && !Scanner.isLetter('9'))
        {
            System.out.println("isLetter pass");
        }
        if(Scanner.isWhiteSpace(' ') && Scanner.isWhiteSpace('\n') && Scanner.isWhiteSpace('\t')
                && Scanner.isWhiteSpace('\r') && !Scanner.isWhiteSpace('j'))
        {
            System.out.println("isWhiteSpace pass");
        }

        System.out.println(scanner.nextToken());
        System.out.println(scanner.nextToken());
        System.out.println(scanner.nextToken());
        System.out.println(scanner.nextToken());
    }
}